/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.awt.EventQueue;

public class Main {

	/**
	 * The main method. Metodo principal, contiene las instrucciones que permiten iniciar el juego.
	 * @param args the arguments
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		EventQueue.invokeLater(new Runnable() {
//			@Override
//			public void run() {
//				EventQueue.invokeLater(new Runnable() {
//                                        @Override
//					public void run() {
//						@SuppressWarnings("unused")
//						Tabla ventana = new Tabla();
//						//GameGUI gameWindow = new GameGUI();
//					}
//				});
//			}
//			
//		});
//	}

}
